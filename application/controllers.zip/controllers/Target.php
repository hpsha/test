<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Target extends CI_Controller {

	function __construct() {
        parent::__construct();

        $this->load->helper('url');
                $this->load->helper('cookie');
                 $this->load->model('Target_Model');
                 $this->load->model('Settings_Model');
                 $this->load->model('Employee_Model');
                 $this->load->model('Master_Model');
				 $this->load->model('Customergroup_Model');

           }
            public function index()
	{
		if(isset($_COOKIE['company_id']))
	    {
	        $data['company_id'] = $_COOKIE['company_id'];
			$company_id = $data['company_id'];
	    }
	    $get_target = $this->Target_Model->get_target($company_id);
		//print_r($get_target);
		//exit();
	    $data['target'] = $get_target;
		$this->load->view('template/header');
		$this->load->view('Target/list_target',$data);
		$this->load->view('template/footer');		
	}
	public function add_target()
	{
	    if(isset($_COOKIE['company_id']))
	    {
	        $data['company_id'] = $_COOKIE['company_id'];
			$company_id = $data['company_id'];
	    }
		$itemgroup = $this->Customergroup_Model->get_itemgroup($company_id);
		$data['itemgroup'] = $itemgroup;
		
	    $roles = $this->Employee_Model->get_employees();
        $data['employee'] = $roles;
	    $settings= $this->Settings_Model->get_settings();

        $data['companies'] = $settings;
		$this->load->view('template/header');
                      $get_month= $this->Target_Model->get_month();
        $data['month'] = $get_month;
        
        $machine = $this->Master_Model->get_machinecategory();
		$data['machinecategory'] = $machine;
		
		$this->load->view('Target/add_target',$data);
                		$this->load->view('template/footer');		


				
	}
		public function add_target_details()
	{

		$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $rand = '';
        $random_string_length = 6;
        $max = strlen($characters) - 1;
        for ($i = 0; $i < $random_string_length; $i++) {
            $rand.= $characters[mt_rand(0, $max)];
        }
		$date = date('Y-m-d H:i:s');
		if($_COOKIE['company_id']==1){
			$data = array(
				't_rand' => $rand,
				't_employee_id' => $_POST['employee'],
				't_company_id' => $_POST['company_id'],
				't_year' => $_POST['year'],
				't_month' => $_POST['month'],
				't_amount' => $_POST['amount'],
				't_machine_category' => $_POST['m_category'],
				't_created_on' => $date,
				't_act' => 1
			);
		}
		else{
			$data = array(
			't_rand' => $rand,
            't_employee_id' => $_POST['employee'],
            't_company_id' => $_POST['company_id'],
            't_year' => $_POST['year'],
            't_month' => $_POST['month'],
            't_amount' => $_POST['amount'],
            't_itemgroup' => $_POST['itemgroup'],
            't_created_on' => $date,
            't_act' => 1
			);
		}
		$this->load->view('template/header');
        $add_target= $this->Target_Model->add_target($data);
        if ($add_target == 1) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
              $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
    }
    $this->input->set_cookie($cookie);
        
        redirect("Target");
				
	}
	
	public function edit_target($key)
	{
		if(isset($_COOKIE['company_id']))
	    {
	        $data['company_id'] = $_COOKIE['company_id'];
			$company_id = $data['company_id'];
	    }
        $this->load->view('template/header');
		$itemgroup = $this->Customergroup_Model->get_itemgroup($company_id);
		$data['itemgroup'] = $itemgroup;
	    $get_month= $this->Target_Model->get_month();
        $data['month'] = $get_month;
		$settings= $this->Settings_Model->get_settings();
        $data['companies'] = $settings;
		 $roles = $this->Employee_Model->get_employees();
        $data['employee'] = $roles;
	   
        $get_target = $this->Target_Model->get_target_list($key);
		 $data['target'] = $get_target;
		// print_r($get_target);
		// exit();
		 
       
        $this->load->view('Target/edit_target',$data);
		$this->load->view('template/footer');
	}
    public function update()
	{	
		$pass = $_POST['key'];
     	$date = date('Y-m-d H:i:s');
		if($_COOKIE['company_id']==1){
			$data = array(
				't_employee_id' => $_POST['employee'],
				't_company_id' => $_POST['company_id'],
				't_year' => $_POST['year'],
				't_month' => $_POST['month'],
				't_amount' => $_POST['amount'],
				't_machine_category' => $_POST['m_category'],
				't_updated_on' => $date,
				't_act' => 1
			);
		}else{
			$data = array(
				't_employee_id' => $_POST['employee'],
				't_year' => $_POST['year'],
				't_month' => $_POST['month'],
				't_amount' => $_POST['amount'],
				't_itemgroup' => $_POST['itemgroup'],
				't_updated_on' => $date,
				't_act' => 1
			);
		}
        $result = $this->Target_Model->update($data,$pass);
        if ($result == 1) {
            $cookie= array(
			   'name'   => 'update',
			   'value'  => '1',
			   'expire' => '3',
			);
        }
		else if ($result == 3) {
            $cookie= array(
			   'name'   => 'update',
			   'value'  => '3',
			   'expire' => '3',
			);
        }
        else{
            $cookie= array(
			   'name'   => 'update',
			   'value'  => '2',
			   'expire' => '3',
			);
		}
    $this->input->set_cookie($cookie);
    redirect("Target");
	}
        
        
}
