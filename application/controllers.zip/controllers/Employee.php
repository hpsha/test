<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	function __construct() {
    parent::__construct();
	$this->load->helper('url');
	$this->load->library('session');
	$this->load->model('Employee_Model');
        //$this->load->library('curl');
    }
	public function index()
	{
           
        $this->load->view('template/header');
        $roles = $this->Employee_Model->get_employees();
        $data['employee'] = $roles;
        $this->load->view('employee/list_employees',$data);
		$this->load->view('template/footer');
	}
	public function add()
	{
        $this->load->view('template/header');
       
        $this->load->view('employee/employee_add');
		$this->load->view('template/footer');
	}
	public function edit_emps($key)
	{
        $this->load->view('template/header');

        $get_emp = $this->Employee_Model->edit_emps($key);
        $data['employee'] = $get_emp;
        $this->load->view('employee/employee_edit',$data);
		$this->load->view('template/footer');
	}
	public function adddetails()
	{
		 $imagePrefix = date('Y_m_d_H_i_s');
		 //$imagename = $imagePrefix.$value['userfile'];
		 $config['upload_path']   = './uploads/';
         $config['allowed_types'] = 'jpeg|jpg|png';
         $config['max_size']      = 100;
         $config['max_width']     = 1024;
         $config['max_height']    = 768;
         $config['file_name'] = $imagePrefix;
         $this->load->library('upload', $config);
         $this->upload->initialize($config);
         $this->upload->do_upload('userfile');
         $upload_data = $this->upload->data();
         $pic=$upload_data['file_name'];
    	//print_r($pic);exit();
		$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $rand = '';
        $random_string_length = 6;
        $max = strlen($characters) - 1;
        for ($i = 0; $i < $random_string_length; $i++) {
            $rand.= $characters[mt_rand(0, $max)];
        }
        $pass=$_POST['emp_pass'];
        $date = date('Y-m-d H:i:s');
        $data = array(
            'employee_rand' => $rand,
            'admin_role_id' => $_POST['role'],
            'employee_name' => $_POST['emp_name'],
            'employee_phone' => $_POST['emp_number'],
            'employee_email' => $_POST['emp_email'],
            'employee_address_line1' => $_POST['emp_addr1'],
            'employee_address_line2' => $_POST['emp_addr2'],
            'employee_address_line3' => $_POST['emp_addr3'],
            'employee_address_line4' => $_POST['emp_addr4'],
            'employee_pincode' => $_POST['emp_pin'],
            'employee_profile' => $pic,
            'employee_created_on' => $date,
            'employee_act' => 1
        );
        $result = $this->Employee_Model->add($data,$pass);
        if ($result == 1) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
              $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
    }
    $this->input->set_cookie($cookie);
    redirect("Employee");
	}
public function delete_employee(){
    $rand=$_POST['id'];
    $value=$_POST['value'];
    $data = array(
    'employee_act' =>$value,);
    $data1 = array(
    	'admin_act' => $value);
    $result = $this->Employee_Model->update_data($data,$rand,$data1);
    echo $result;
    }
    public function update()
	{
        //print_r($_POST);exit();
     	$rand=$_POST['key'];
        $date = date('Y-m-d H:i:s');
        $data = array(
            'employee_name' => $_POST['emp_name'],
            'employee_updated_on' => $date,
            'employee_act' => 1
        );
        $result = $this->Employee_Model->update_emp($data,$rand);
        if ($result == 1) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
              $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
    }
    $this->input->set_cookie($cookie);
    redirect("Employee");
	}			public function export(){			        $get_employee= $this->Employee_Model->get_export_companies();        $data['employee'] = $get_employee;        $this->load->view('employee/export_employee',$data);	}
}