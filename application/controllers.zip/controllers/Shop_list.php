<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Shop_list extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('cookie');
        $this->load->model('Terms_Model');
    }

    public function index()
    {
        $this->load->view('template/header');
        $get_companies = $this->Terms_Model->fetch_shop_list();
        $data['shop'] = $get_companies;
        //print_r($get_companies);
        //exit();
        $this->load->view('Terms/list_terms', $data);

        $this->load->view('template/footer');
    }
      public function Search()
    {
        $this->load->view('template/header');
        if(isset($_POST['from'])){
          $froms = $_POST['from'];

    $from = date("Y-m-d", strtotime($froms));
        }
    else{
        $from="1970-01-01";
    }
     if(isset($_POST['to'])){
    $tos =$_POST['to'];
    $to = date("Y-m-d", strtotime($tos));
     }
   else{
          $to = date("Y-m-d");
    }

        $get_companies = $this->Terms_Model->fetch_shop_lists($from,$to);
        $data['shop'] = $get_companies;
        //print_r($get_companies);
        //exit();
        $this->load->view('Terms/list_terms', $data);

        $this->load->view('template/footer');
    }


    public function shop_view($shop_id)
    {
        $this->load->view('template/header');

        $get_companies = $this->Terms_Model->fetch_shop_view($shop_id);
        $data['shop_view'] = $get_companies;
        $get_img = $this->Terms_Model->fetch_shop_view_img($shop_id);
        $data['shop_view_img'] = $get_img;
        $data['shop_id']=$shop_id;


         $this->load->view('Terms/shop_view',$data);
        $this->load->view('template/footer');
    }
     public function shop_views($shop_id)
    {
        $this->load->view('template/header');

        $get_companies = $this->Terms_Model->fetch_shop_views($shop_id);
        $data['shop_view'] = $get_companies;
        $get_img = $this->Terms_Model->fetch_shop_view_img($shop_id);
        $data['shop_view_img'] = $get_img;


         $this->load->view('Terms/shop_views',$data);
        $this->load->view('template/footer');
    }
    public function shop_view_pdf($shop_id)
    {

        $get_companies = $this->Terms_Model->fetch_shop_view($shop_id);
        $shop_view1= $get_companies;
        $shop_view=$shop_view1[0];
        //print_r($shop_view);exit();
        $this->load->library('Pdf');
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Nicola Asuni');
        $pdf->SetTitle('Order Invoice');
        $pdf->SetSubject('TCPDF Tutorial');
        $pdf->SetKeywords('TCPDF, PDF, example, test, guide');
        $pdf->setFooterFont(Array(
            PDF_FONT_NAME_DATA,
            '',
            PDF_FONT_SIZE_DATA
        ));
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
        if (@file_exists(dirname(__FILE__) . '/lang/eng.php')) {
            require_once(dirname(__FILE__) . '/lang/eng.php');
            $pdf->setLanguageArray($l);
        }
        $pdf->SetFont('times', '', 12);
        $pdf->AddPage();
            $where="tbl_shop.shop_id=$shop_id";
                                                   $count = $this->db->select('tbl_shop.shop_name,tbl_product.product_name,tbl_productgroup.productgroup_name,qty,price')
			->join('tbl_product','tbl_product.product_id=tbl_order.product_id')
					->join('tbl_productgroup','tbl_productgroup.productgroup_id=tbl_order.product_group_id')
					->join('tbl_shop','tbl_shop.shop_id=tbl_order.shop_id')->from('tbl_order')->where($where)->get()->num_rows();
					
                                                 $q = $this->db->select('tbl_shop.shop_name,tbl_product.product_name,tbl_productgroup.productgroup_name,qty,price')
			->join('tbl_product','tbl_product.product_id=tbl_order.product_id')
					->join('tbl_productgroup','tbl_productgroup.productgroup_id=tbl_order.product_group_id')
					->join('tbl_shop','tbl_shop.shop_id=tbl_order.shop_id')->from('tbl_order')->where($where)->get()->result();
					 $price=0;$qqs='';
					if($count>0){
					     foreach($q as $data){
					        $prices=$data->price;
					        $price=$prices+$price;
        $qqs.="<tr><td>$data->product_name</td><td>$data->productgroup_name</td><td>$data->qty</td><td>$data->price</td></tr>";
					    
					}
					}
					else{
					    $qqs.="";
					 $price=0;   
					}
                                          
        $txt = <<<EOD
<style>
body{
                font-size:14px;
                font-familly:Times New Roman;
            }
 table,td{
                //border: 1px solid black;
                border-collapse: collapse;
            }
 .right{
    text-align:right;
 }
</style>
<body>
<table>
<tr>
<td rowspan="2"><img src="http://anilfoods.in/uploads/2018-02-07_10_19_22.png" width="75px" height="75px"></td>
<td></td>
</tr>
<tr>
<td style="font-size:18px"><b>Order Form</b></td>
</tr>
</table>
<hr>
<p></p>
<center><b>A.R Super Market</b><p>$shop_view->shop_owner_name</p></center>
<hr>
<p></p>
<center><p>Agencies : $shop_view->agencies_name</p><p>Location : $shop_view->location_name</p></center>
<table>
    <tr>
    <td>Shop Contact</td>
    <td>$shop_view->shop_contact</td>
    </tr>
    <tr>
    <td>Shop Landmark</td>
    <td>$shop_view->shop_landline</td>
    </tr>
    <tr>

    <td>Shop Order value</td>
    <td>Rs $shop_view->shop_location</td>
    </tr>
    <tr>
    <td>Shop Location</td>
    <td>$shop_view->address</td>
    </tr>
    <tr>
    <td>Previous Supplier</td>
    <td>$shop_view->shop_previous</td>
    </tr>
    <tr>
    <td>Shop Type</td>
    <td>$shop_view->shop_type</td>
    </tr>
    <tr>
    <td>Remarks</td>
    <td>$shop_view->remarks</td>
    </tr>
</table>
</body>
EOD;
        $pdf->writeHTML($txt, true, false, true, false, '');
        
        $txts = <<<EOD
<style>
body{
                font-size:14px;
                font-familly:Times New Roman;
            }
 table,td{
               
                border-collapse: collapse;
                padding:5px
            }
 .right{
    text-align:right;
 }
 .tables td{
      border: 1px solid black;
 }
</style>
<body>
<table>

<tr>
<td style="font-size:18px"><b>Order Details</b></td>
</tr>
</table>
<hr>
<hr>
<table class="tables">
  <thead>
                                            <tr>
                                                <td><b>Name</b></td>
                                                <td><b>Group</b></td>
                                                 <td><b>Qty</b></td>
                                                  <td><b>Price</b></td>
                                            </tr>
                                        </thead>
                                         <tbody>
                                         $qqs
                                         </tbody>
                                         <tfoot>
                                        <tr>
                                                <td style="text-align:right" colspan="4">GrandTotal:<strong>Rs.$price</strong></td>
                                            </tr>
                                         </tfoot>
</table>
</body>
EOD;
             $pdf->writeHTML($txts, true, false, true, false, '');
                           
        $pdf->Output('orderform.pdf','D');
    }

        public function delete_shops()
    {
        $date = date('Y-m-d H:i:s');
        $id = $_POST['id'];
        $data = array(
            'shop_act' => 0
        );
        $result = $this->Terms_Model->update_data($data, $id);
        echo $result;
    }

   /* public function inactive()
    {
        $this->load->view('template/header');
        $get_companies = $this->Terms_Model->get_inactiveterms();
        $data['companies'] = $get_companies;
        $this->load->view('Terms/list_inactive_terms', $data);
        $this->load->view('template/footer');
    }
        public function add()
    {
         $get_companies = $this->Company_Model->get_companies_name();
        $data['companies'] = $get_companies;
        $this->load->view('template/header');
$this->load->view('Terms/add_terms',$data);
        $this->load->view('template/footer');
    }
    public function editterms($key)
    {
        $this->load->view('template/header');
         $get_companies = $this->Company_Model->get_companies_name();
        $data['companies'] = $get_companies;
        $get_terms = $this->Terms_Model->get_singleterms($key);
        $data['get_terms'] = $get_terms;
        $this->load->view('Terms/edit_terms', $data);
        $this->load->view('template/footer');
    }
    public function adddetails()
    {
      $terms= $_POST['repeater-list'];
      $company= $_POST['company'];
        $dups = array();
        $input = array_map("unserialize", array_unique(array_map("serialize", $terms)));
        $repeater_count = count($terms);
        $duplicate_count = count($input);
        if ($duplicate_count != $repeater_count) {
          $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
              $this->input->set_cookie($cookie);
    redirect("Terms");
        }
        foreach($terms as $t){
             $characters           = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $rand                 = '';
        $random_string_length = 6;
        $max                  = strlen($characters) - 1;
        for ($i = 0; $i < $random_string_length; $i++) {
            $rand .= $characters[mt_rand(0, $max)];
        }
        $date = date('Y-m-d H:i:s');
            $data  = array(
            'term_condition_rand' => $rand,
            'term_condition_data' =>  $t['document_name'],
            'company_id' => $company,
                'term_condition_act' => 1,
            'term_condition_created_on' => $date
        );
           $result = $this->Terms_Model->add_data($data);
        }
        if ($result == 1) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
              $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
        }
                        $this->input->set_cookie($cookie);
    redirect("Terms");
    }
    public function updateterms()
    {

        $date = date('Y-m-d H:i:s');
        $rand = $_POST['terms_rand'];
        $data = array(
            'term_condition_data' => $_POST['document_name'],
            'company_id' => $_POST['company'],

        );
        $result = $this->Terms_Model->update_data($data, $rand);
        if ($result == 1) {
            $cookie = array(
                'name' => 'update',
                'value' => '1',
                'expire' => '3'
            );
        }
        else if ($result == 3) {
            $cookie = array(
                'name' => 'update',
                'value' => '3',
                'expire' => '3'
            );
        } else {
            $cookie = array(
                'name' => 'update',
                'value' => '2',
                'expire' => '3'
            );
        }
        $this->input->set_cookie($cookie);
        redirect("Terms");
    }

    public function activate_terms()
    {
        $date = date('Y-m-d H:i:s');
        $rand = $_POST['id'];
        $data = array(
            'term_condition_act' => 1
        );
        $result = $this->Terms_Model->update_data($data, $rand);
        echo $result;
    }*/
}