<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Agent extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('Agent_Model');
        $this->load->helper('cookie');
        if (is_logged_in() == true) {
            redirect("Welcome");
        }
    }
    public function index()
    {
        $this->load->view('template/header');
        $get_agents = $this->Agent_Model->get_agents();
        $data['agents'] = $get_agents;
        $this->load->view('agent/list_agent',$data);
        $this->load->view('template/footer');
    }
    public function inactive()
    {
        $this->load->view('template/header');
        $get_agents = $this->Agent_Model->get_inactiveagents();
        $data['agents'] = $get_agents;
        $this->load->view('agent/list_agent',$data);
        $this->load->view('template/footer');
    }
    public function add_agent()
    {
        $this->load->view('template/header');
        $this->load->view('agent/agent_add');
        $this->load->view('template/footer');
    }
    public function edit_agent($key)
    {
        $this->load->view('template/header');
        $get_agent = $this->Agent_Model->get_agent($key);
        $data['agent'] = $get_agent;
        $this->load->view('agent/agent_edit',$data);
        $this->load->view('template/footer');
    }
    public function add()
    {
        //echo "<pre>"; print_r($_POST);exit();
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $rand = '';
        $random_string_length = 6;
        $max = strlen($characters) - 1;
        for ($i = 0; $i < $random_string_length; $i++) {
            $rand.= $characters[mt_rand(0, $max)];
        }
        $date = date('Y-m-d H:i:s');
        $data = array(
            'agent_rand' => $rand,
            'agent_name' => $_POST['agnt_name'],
            'agent_phone' => $_POST['agnt_number'],
            'agent_email' => $_POST['agnt_mail'],
            'agent_address_line1' => $_POST['agnt_addr1'],
            'agent_address_line2' => $_POST['agnt_addr2'],
            'agent_address_line3' => $_POST['agnt_addr3'],
            'agent_address_line4' => $_POST['agnt_addr4'],
            'agent_pincode' => $_POST['agnt_pin'],
            'agent_additional_contact1' => $_POST['additional_contact1'],
            'agent_additional_contact2' => $_POST['additional_contact2'],
            'agent_additional_email1' => $_POST['additional_email1'],
            'agent_additional_email2' => $_POST['additional_email2'],
            'agent_act' => 1,
            'agent_created_on' => $date,
        );
        $result = $this->Agent_Model->add($data);
        if ($result == 1) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
             $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
    }
    $this->input->set_cookie($cookie);
    redirect("Agent");
}
public function delete_agent(){
    $rand=$_POST['id'];
    $data = array(
    'agent_act' =>0,);
    $result = $this->Agent_Model->update_data($data,$rand);
    echo $result;
    }
public function activate_agent(){
    $rand=$_POST['id'];
    $data = array(
    'agent_act' =>1,);
    $result = $this->Agent_Model->update_data($data,$rand);
    echo $result;
    }
public function update()
    {
        //echo "<pre>"; print_r($_POST);exit();
        $key=$_POST['key'];
        $date = date('Y-m-d H:i:s');
        $data = array(
            'agent_rand' => $_POST['key'],
            'agent_name' => $_POST['agnt_name'],
            'agent_phone' => $_POST['agnt_number'],
            'agent_email' => $_POST['agnt_mail'],
            'agent_address_line1' => $_POST['agnt_addr1'],
            'agent_address_line2' => $_POST['agnt_addr2'],
            'agent_address_line3' => $_POST['agnt_addr3'],
            'agent_address_line4' => $_POST['agnt_addr4'],
            'agent_pincode' => $_POST['agnt_pin'],
            'agent_additional_contact1' => $_POST['additional_contact1'],
            'agent_additional_contact2' => $_POST['additional_contact2'],
            'agent_additional_email1' => $_POST['additional_email1'],
            'agent_additional_email2' => $_POST['additional_email2'],
            'agent_act' => $_POST['status'],
            'agent_updated_on' => $date,
        );
        $result = $this->Agent_Model->update_data($data,$key);
        if ($result == 1) {
            $cookie= array(
           'name'   => 'update',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'update',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
              $cookie= array(
           'name'   => 'update',
           'value'  => '2',
           'expire' => '3',
       );
    }
    $this->input->set_cookie($cookie);
    redirect("Agent");
}
	public function export(){
        $get_agent= $this->Agent_Model->get_export_agent();
        $data['agent'] = $get_agent;
        $this->load->view('agent/export_agent',$data);
}
}

