<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agencies extends CI_Controller {

	function __construct() {
    parent::__construct();
	$this->load->helper('url');
	$this->load->library('session');
	$this->load->model('Enquiry_Model');   
	$this->load->model('Employee_Model');

        //$this->load->library('curl');
    }
	public function index()
	{
           
        $this->load->view('template/header');
        $roles = $this->Enquiry_Model->get_agencies();
	
        $data['employee'] = $roles;
        $this->load->view('agencies/list_agencies',$data);
		$this->load->view('template/footer');
	}
	public function reports()
	{
           
        $this->load->view('template/header');
        if(isset($_POST['from'])){
        $date=$_POST['from'];
        $date=date("Y-m-d", strtotime($date));
        }
        else{
             $date=date("Y-m-d");
        }
        $roles = $this->Enquiry_Model->get_agenciesreports($date);

        $data['employee'] = $roles;
          $data['date'] = $date;
        $this->load->view('agencies/list_agencies_reports',$data);
		$this->load->view('template/footer');
	}
public function edit_agencies($id)
  {
        $this->load->view('template/header');
        $get_task = $this->Enquiry_Model->fetch_agencies($id);

        $roles = $this->Employee_Model->get_employees();
        $data['employee'] = $roles;

        $data['fetch_task'] = $get_task;
        $this->load->view('agencies/agency_edit',$data);
        $this->load->view('template/footer');
  }
  public function get_location()
  {
      $agency_id=$_POST['id'];
           $where = "agency_id ='$agency_id'";
        $q = $this->db->select('*')->from('tbl_agencies_location')->where($where)->get()->num_rows();
        $response = array();
$option='';
        if ($q > 0) {
              $where = "agency_id ='$agency_id'";
            $q = $this->db->select('location_id')->from('tbl_agencies_location')->where($where)->get()->result();
            foreach($q as $location){
                $ids=$location->location_id;
                $wheres="location_id=$ids";
                                            $qss = $this->db->select('location_id,location_name')->from('tbl_location')->where($wheres)->get()->num_rows();
if($qss>0){
                            $qs = $this->db->select('location_id,location_name')->from('tbl_location')->where($wheres)->get()->row();
                                                       

                            $location_name=$qs->location_name;
                                                        $location_id=$qs->location_id;
                                                        $option.="<option value='$location_id'>$location_name</option>";
}


            }
            
echo $option;
  
        }
  }
  
	public function edit_employee($key)
	{
        $this->load->view('template/header');

        $get_emp = $this->Employee_Model->get_employee($key);
        $data['employee'] = $get_emp;
       echo $this->db->last_query();
        print_r($get_emp);exit();
        $this->load->view('employee/employee_edit',$data);
		$this->load->view('template/footer');
	}
	public function delete_employee(){
    $rand=$_POST['id'];
    $value=$_POST['value'];
    $data = array(
    'employee_act' =>$value,);
    $data1 = array(
    	'admin_act' => $value);
    $result = $this->Employee_Model->update_data($data,$rand,$data1);
    echo $result;
    }
    public function update()
	{
		if($_FILES['userfile']['name']!=''){
		 $imagePrefix = date('Y_m_d_H_i_s');
		 //$imagename = $imagePrefix.$value['userfile'];
		 $config['upload_path']   = './uploads/';
         $config['allowed_types'] = 'jpeg|jpg|png';
         $config['max_size']      = 100;
         $config['max_width']     = 1024;
         $config['max_height']    = 768;
         $config['file_name'] = $imagePrefix;
         $this->load->library('upload', $config);
         $this->upload->initialize($config);
         $this->upload->do_upload('userfile');
         $upload_data = $this->upload->data();
         $pic=$upload_data['file_name'];
    	//print_r($pic);exit();
     	}
     	else{
     		$pic=$_POST['filename'];
     	}
     	$rand=$_POST['key'];
        $pass=$_POST['emp_pass'];
        $date = date('Y-m-d H:i:s');
        $data = array(
            'employee_rand' => $rand,
            'admin_role_id' => $_POST['role'],
            'employee_name' => $_POST['emp_name'],
            'employee_phone' => $_POST['emp_number'],
            'employee_email' => $_POST['emp_email'],
            'employee_address_line1' => $_POST['emp_addr1'],
            'employee_address_line2' => $_POST['emp_addr2'],
            'employee_address_line3' => $_POST['emp_addr3'],
            'employee_address_line4' => $_POST['emp_addr4'],
            'employee_pincode' => $_POST['emp_pin'],
            'employee_profile' => $pic,
            'employee_created_on' => $date,
            'employee_act' => 1
        );
        $result = $this->Employee_Model->update($data,$pass,$rand);
        if ($result == 1) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else if ($result == 3) {
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
        }
        else{
              $cookie= array(
           'name'   => 'success',
           'value'  => '2',
           'expire' => '3',
       );
    }
    $this->input->set_cookie($cookie);
    redirect("Employee");
	}		
	public function export(){			    
	    $get_employee= $this->Employee_Model->get_export_companies();   
	    $data['employee'] = $get_employee;   
	$this->load->view('employee/export_employee',$data);	}
	 public function add()
  {
        $this->load->view('template/header');

        $roles = $this->Employee_Model->get_employees();
        $data['employee'] = $roles;
         $roles = $this->Enquiry_Model->get_agencies();
	
        $data['agency'] = $roles;

        $this->load->view('agencies/add_agencies',$data);
        $this->load->view('template/footer');
  }
  	 public function addnew()
  {
        $this->load->view('template/header');

        $roles = $this->Employee_Model->get_employees();
        $data['employee'] = $roles;
         $roles = $this->Enquiry_Model->get_agencies();
	
        $data['agency'] = $roles;

        $this->load->view('agencies/addnew',$data);
        $this->load->view('template/footer');
  }
  public function adddetails()
  {

	$name=$_POST['name'];
		$created_by=$_POST['created_by'];
		$Locations=$_POST['Locations'];
		$from=$_POST['from'];
		$i=implode(',',$created_by);
 
 $from=date('Y-m-d', strtotime($from));

 $s="INSERT INTO `tbl_agencies_locations`(`id`, `agency_id`, `location_id`, `emp_id`, `date`, `act`) VALUES ('','$name','$Locations','$i','$from',1)";

$qq=$this->db->query("$s");

        if ($qq) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else{
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );

    }
    $this->input->set_cookie($cookie);
    redirect("Agencies");
  }
  
   public function addnewdetails()
  {
	$name=$_POST['name'];
		$list=$_POST['repeater-list'];
		$date=date("Y-m-d H:i:s");

	 $data  = array(
            'agencies_name' =>  $name=$_POST['name'],
         'agencies_act'=>1,
            '	agencies_created_on' => $date
        );
                   $q=$this->db->insert('tbl_agencies', $data);
                   $id= $this->db->insert_id();

        foreach($list as $t){
$datas  = array(
            'location_name' =>  $t['document_name'],
         'location_act'=>1,
            '	location_created_on' => $date
        );
            $this->db->insert('tbl_location', $datas);
        $ids=$this->db->insert_id();
        $datasy  = array(
            'agency_id' => $id,
         'location_id'=>$ids,
            'act' => 1
        );
            $this->db->insert('tbl_agencies_location', $datasy);
        }
         if ($q) {
            $cookie= array(
           'name'   => 'success',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else{
             $cookie= array(
           'name'   => 'success',
           'value'  => '3',
           'expire' => '3',
       );
       }

       

    $this->input->set_cookie($cookie);
    redirect("Agencies");
  }


 public function updatedetails()
  {
      $user_id=$_POST['created_by'];
      $title=$_POST['name'];
       $insert_id=$_POST['key'];
      $notes="";
      $status=0;
      $date=  date('y-m-d H:i:s');
     $q=$this->db->query("update tbl_agencies set 	agencies_name='$title',agencies_emp_id='$user_id' where 	agencies_id=$insert_id");
	  
	 
        $terms= $_POST['repeater-list'];
        $dups = array();
        $input = array_map("unserialize", array_unique(array_map("serialize", $terms)));
        $repeater_count = count($terms);
        $duplicate_count = count($input);
                    $q=$this->db->query("update tbl_location set 	location_act=0 where location_agenciesid=$insert_id");

        foreach($terms as $t){
             if($t['location_id']==''){
        $date = date('Y-m-d H:i:s');
            $data  = array(
            'location_agenciesid' => $insert_id,
            'location_name' =>  $t['document_name'],
            'location_act' => 1,
            'location_created_on' => $date
        );
           $this->db->insert('tbl_location', $data);
             }
             else{
                    $date = date('Y-m-d H:i:s');
      
            $location_name =  $t['document_name'];
               $location_id =  $t['location_id'];
           
             $q=$this->db->query("update tbl_location set 	location_name='$location_name',location_act=1 where location_id=$location_id");


        
             }
        }
	 
	 
        if ($q) {
            $cookie= array(
           'name'   => 'update',
           'value'  => '1',
           'expire' => '3',
       );
        }
       else{
             $cookie= array(
           'name'   => 'update',
           'value'  => '3',
           'expire' => '3',
       );

    }
    $this->input->set_cookie($cookie);
    redirect("Agencies");
  }
}