<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function orders()
	{
		$this->load->library('Pdf');
		class MYPDF extends TCPDF {

    //Page header
    public function Header() {
        // Logo
        //$image_file = base_url('images/logo.png');

        //Image($file, $x='', $y='', $w=0, $h=0, $type='', $link='', $align='', $resize=false, $dpi=300, $palign='', $ismask=false, $imgmask=false, $border=0, $fitbox=false, $hidden=false, $fitonpage=false)


       /* $this->Image($image_file, 10, 10, 32, '', 'PNG', '', 'T', false, 300, '', false, false, 2, false, false, false);*/
        // Set font
        $this->SetFont('helvetica', 'B', 12);
        // Title
        #Cell(w, h = 0, txt = '', border = 0, ln = 0, align = '', fill = 0, link = nil, stretch = 0, ignore_min_height = false, calign = 'T', valign = 'M')
        /*$this->Cell(11, 0, 'SIMTA MACHINERY PRIVATE LIMITED', 0, false, 'L', 0, '', 0, false, 'T', 'M');
        $this->SetFont('helvetica', '', 10);
        $this->Ln();
        $this->Cell(84, 0, 'RAILWAY FEEDER ROAD ,SULUR', 0, 0, 'R', 0, '', 0, false, 'T', 'M');*/

    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 5, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}
//define ('PDF_HEADER_TITLE', 'SIMTA MACHINERY PRIVATE LIMITED');
// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('Order Invoice');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('times', '', 12);
//$pdf->setCellHeightRatio(.8);

// add a page
$pdf->AddPage();
// set some text to print
$txt = <<<EOD
<style>
body{
                font-size:14px;
                font-familly:Times New Roman;
            }
 table,td{
                //border: 1px solid black;
                border-collapse: collapse;
            }
 .right{
    text-align:right;
 }
</style>
<body>
<table>
<tr>
<td colspan="0" rowspan="5"><img src="images/logo.png" width="100px" height="80px"></td>
<td colspan="6"><b>SIMTA MACHINERY PRIVATE LIMITED</b></td>
</tr>
<tr>
<td colspan="6">RAILWAY FEEDER ROAD ,SULUR</td>
</tr>
<tr>
<td colspan="6">COIMBATORE-641 103</td>
</tr>
<tr>
<td colspan="6">GSTIN: 33AAGCS6627J1Z5</td>
</tr>
<tr>
<td colspan="6">Ph:04222680705 04222687255</td>
</tr>
</table>
<hr>
<p></p>
<table>
<tr>
<td>Proforma Inv No : </td>
<td colspan="5">SIMTA/PROFORMA/JAN/327</td>
</tr>
<tr>
<td>Proforma Inv Dt : </td>
<td colspan="5">25-Jan-2018</td>
</tr>
</table>
<p></p><p></p><p></p>
<p>To,</p>
<div>SAKKU SPINNING MILLS PRIVATE LTD</div>
SURVEY NO :110/J,110/K,110/L,
<div>CHINAKONDRUPADU, PRATHIPADU,</div>
GUNTUR (DIST), -522019
<p></p>
<p class="sub">Sub: Your Valuable Order No : 1602 DT. 22.01.2018 Dated : 1/25/2018 10:02:53AM</p>
<p>Dear Sir,</p>
<div>We refer to your Valuable Order and we are enclosing herewith our Proforma Invoice No :
SIMTA/PROFORMA/JAN/327 Dated : 1/25/2018 for 25,490.00 (Twenty Five Thousand Four
Hundred And Ninety Only)
<p>We request you to release the payment to enable us dispatch the material.</p>
<p>We are also enclosing here with To clear the consignment.</p>
<p></p><p></p><p></p><p></p>
<p>Thanking You and assuring of our best service</p>
<p></p><p></p><p></p><p></p>
<p>Yours faithfully,</p>
<p></p>
<p>For <b>SIMTA MACHINERY PRIVATE LIMITED</b></p>
<p></p>
<p><b>Authorised Signatory</b></p>
</body>
EOD;

// print a block of text using Write()
$pdf->writeHTML($txt, true, false, true, false, '');
$pdf->AddPage();
$txt1 = <<<EOD
<style>
body{
                font-size:12px;
                font-familly:Times New Roman;
            }
 table,td{
                //border: 1px solid black;
                border-collapse: collapse;
            }
 .right{
    text-align:right;
 }
 .address{
    //border: 1px solid black;
    border-radius: 25px;
 }
</style>
<body>
<table>
<tr>
<td colspan="0" rowspan="6"><img src="images/logo.png" width="250px" height="250px"></td>
<td colspan="6"><b>SIMTA MACHINERY PRIVATE LIMITED</b></td>
</tr>
<tr>
<td width="300">RAILWAY FEEDER ROAD ,SULUR
</td>
<td class="right">Proforma Inv No :</td>
<td colspan="2">327</td>
</tr>
<tr>
<td>COIMBATORE-641 103</td>
<td class="right">Proforma Inv Dt :</td>
<td colspan="2">25-Jan-2018</td>
</tr>
<tr>
<td>GSTIN: 33AAGCS6627J1Z5</td>
<td class="right">Rev No :</td>
<td colspan="2">0</td>
</tr>
<tr>
<td>Ph:04222680705 04222687255</td>
<td class="right">Ref Doc No :</td>
<td colspan="2">1602 DT. 22.01.2018</td>
</tr>
<tr>
<td>Email:ohtc@simta.com WebSite:www.simta.com</td>
<td class="right">Ref Doc Dt :</td>
<td colspan="2">20-Jan-2018</td>
</tr>
</table>
<hr>
<p></p>
<table width="100%">
<tr>
<td><b>Billing Address</b></td>
<td><b>Shipping Address</b></td>
</tr>
<tr>
<td>SAKKU SPINNING MILLS PRIVATE LTD</td>
<td>SAKKU SPINNING MILLS PRIVATE LTD</td>
</tr>
<tr>
<td>SURVEY NO :110/J,110/K,110/L,</td>
<td>SURVEY NO :110/J,110/K,110/L,</td>
</tr>
<tr>
<td>CHINAKONDRUPADU, PRATHIPADU,</td>
<td>CHINAKONDRUPADU, PRATHIPADU,</td>
</tr>
<tr>
<td>Pincode: 522019</td>
<td>Pincode: 522019</td>
</tr>
<tr>
<td>ANDHRA PRADESH</td>
<td></td>
</tr>
<tr>
<td>GST Tin :37AAJCS6186M1Z </td>
<td>GST Tin :37AAJCS6186M1Z </td>
</tr>
<tr>
<td>TIN NO: 37262537544</td>
<td>TIN NO: 37262537544</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Agent : Direct</td>
<td>Agent : Direct</td>
</tr>
</table>
</body>
EOD;
$pdf->writeHTML($txt1, true, false, true, false, '');
$tb2 = <<<EOD
<style>
            body{
                font-size:12px;
                font-familly:Times New Roman;
            }
            table,td{
                border: 1px solid balck;
                border-collapse: collapse;
                padding: 7px;
            }
            td{
                text-align: center
            }
            .hed{
                text-align:center;
            }
            .date{
                text-align:right;
            }
            .mar{
                margin-top: 100px;
            }
        </style>
        <body>
<table width="100%">
        <tr>
        <td width="40"><b>S.No</b></td>
        <td width="40"><b>PartNo</b></td>
        <td width="340"><b>Item Description</b></td>
        <td width="50"><b>UOM</b></td>
        <td width="70"><b>Quantity</b></td>
        <td width="70"><b>Price Per Unit</b></td>
        <td width="80"><b>Total Value</b></td>
        </tr>
        <tr>
        <td>1</td>
        <td></td>
        <td>CONTACTOR 9 A , 24 V - 510 03</td>
        <td>NOS</td>
        <td>4.00</td>
        <td>1,172.00</td>
        <td>4,688.00</td>
        </tr>
        <tr>
        <td>2</td>
        <td></td>
        <td>PLC 8/6 (SIEMENS) - 510 17</td>
        <td>NOS</td>
        <td>2.00</td>
        <td>8,920.00</td>
        <td>17,840.00</td>
        </tr>
        <tr>
        <td colspan="4"  rowspan="7" align="center"><b>Rupees: Twenty Five Thousand Four Hundred And Ninety Only</b></td>
        <td width="110"><b>Subtotal</b></td>
        <td width="110">Rs 22,528.00</td>
        </tr>
        <tr>
        <td><b>Discount 5.00 %</b></td>
        <td>Rs 1,126.40</td>
        </tr>
        <tr>
        <td><b>Packing</b></td>
        <td>Rs 200.00</td>
        </tr>
        <tr>
        <td><b>IGST @ 18%</b></td>
        <td>Rs 3,888.29</td>
        </tr>
        <tr>
        <td><b>Grand Total</b></td>
        <td>Rs 25,489.89</td>
        </tr>
        <tr>
        <td><b>R.Off</b></td>
        <td>Rs 0.11</td>
        </tr>
        <tr>
        <td><b>Nett Amount</b></td>
        <td>Rs 25,490.00</td>
        </tr>
</table>
</body>
EOD;
$pdf->writeHTML($tb2, true, false, false, false, '');
$tb3 = <<<EOD
<style>
            body{
                font-size:12px;
                font-familly:Times New Roman;
            }
            table,td{
                //border: 1px solid balck;
                border-collapse: collapse;
            }
        </style>
        <body>
<table width="100%">
<tr>
<td align="right"><b>Terms and Conditions</b></td>
<td></td>
</tr>
<tr>
<td><b>Terms</b></td>
<td><b>Description</b></td>
</tr>
<tr>
<td>PRICE</td>
<td>EX-WORKS</td>
</tr>
<tr>
<td>VALIDITY</td>
<td>45 DAYS</td>
</tr>
<tr>
<td>PAYMENT TERMS</td>
<td>30% WITH ORDER & 70 % AGAINST PROFORMA INVOICE</td>
</tr>
<tr>
<td>DELIVERY TERMS</td>
<td>4 TO 6 WEEKS</td>
</tr>
<tr>
<td>ERECTION CHARGES</td>
<td>1500/DAY</td>
</tr>
<tr>
<td>TO&FRO</td>
<td>Road Permit is Compulsory</td>
</tr>
<tr>
<td>BOARDING&LODGING</td>
<td>TO&FRO, BOARDING&LODGING</td>
</tr>
<tr>
<td>PACKET ALLOWANCE</td>
<td>0.22% EXTRA AT YOUR COST</td>
</tr>
<tr>
<td>EXTRA</td>
<td>0.22% EXTRA AT YOUR COST</td>
</tr>
</table>
<p></p>
<hr>
<span>Bank : SBI ,    Branch : Coimbatore ,    Account : 09876654321677886 ,    IFSC: SBI98765447
</body>
EOD;
$pdf->writeHTML($tb3, true, false, false, false, '');
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('orders.pdf', 'I');
	}
	public function enquiry()
	{
		$this->load->library('Pdf');
		class MYPDF extends TCPDF {

    //Page header
    public function Header() {
        // Logo
        //$image_file = base_url('images/logo.png');

        //Image($file, $x='', $y='', $w=0, $h=0, $type='', $link='', $align='', $resize=false, $dpi=300, $palign='', $ismask=false, $imgmask=false, $border=0, $fitbox=false, $hidden=false, $fitonpage=false)


       /* $this->Image($image_file, 10, 10, 32, '', 'PNG', '', 'T', false, 300, '', false, false, 2, false, false, false);*/
        // Set font
        $this->SetFont('helvetica', 'B', 12);
        // Title
        #Cell(w, h = 0, txt = '', border = 0, ln = 0, align = '', fill = 0, link = nil, stretch = 0, ignore_min_height = false, calign = 'T', valign = 'M')
        /*$this->Cell(11, 0, 'SIMTA MACHINERY PRIVATE LIMITED', 0, false, 'L', 0, '', 0, false, 'T', 'M');
        $this->SetFont('helvetica', '', 10);
        $this->Ln();
        $this->Cell(84, 0, 'RAILWAY FEEDER ROAD ,SULUR', 0, 0, 'R', 0, '', 0, false, 'T', 'M');*/

    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 5, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}
//define ('PDF_HEADER_TITLE', 'SIMTA MACHINERY PRIVATE LIMITED');
// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('Enquiry Invoice');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('times', '', 12);
//$pdf->setCellHeightRatio(.8);

// add a page
$pdf->AddPage();
// set some text to print
$txt = <<<EOD
<style>
body{
                font-size:14px;
                font-familly:Times New Roman;
            }
 table,td{
                //border: 1px solid black;
                border-collapse: collapse;
            }
 .right{
    text-align:right;
 }
</style>
<body>
<table>
<tr>
<td colspan="0" rowspan="5"><img src="images/logo.png" width="100px" height="80px"></td>
<td colspan="6"><b>SIMTA MACHINERY PRIVATE LIMITED</b></td>
</tr>
<tr>
<td colspan="6">RAILWAY FEEDER ROAD ,SULUR</td>
</tr>
<tr>
<td colspan="6">COIMBATORE-641 103</td>
</tr>
<tr>
<td colspan="6">GSTIN: 33AAGCS6627J1Z5</td>
</tr>
<tr>
<td colspan="6">Ph:04222680705 04222687255</td>
</tr>
</table>
<hr>
<p></p>
<table>
<tr>
<td>Quote No : </td>
<td colspan="8">SIMTA/QUOTE/JAN/3091/R2</td>
</tr>
<tr>
<td>Quote Dt : </td>
<td colspan="8">23-Jan-2018</td>
</tr>
</table>
<p></p><p></p><p></p>
<p>To,</p>
<div>BHASKAR INDUSTRIES (P) LTD.,</div>
WORKS : PLOT NO 15, 16 SECTOR - D,
<div>INDUSTRIAL AREA, MANDIDEEP,</div>
RAISEN ( M.P) - 462046.
<p></p>
<p class="sub">Sub: Your Enquiry No : REFERENCE WITH MR.GOPAL ARYA Dated : 1/20/2018 5:00:18PM</p>
<p>Dear Sir,</p>
<div>We refer to your enquiry and we are enclosing herewith our Quotation No :</div>
SIMTA/QUOTE/JAN/3091/R2 Dated : 1/23/2018 for 744,073.00 (Seven Lakhs Forty Four
Thousand Seventy Three Only)
<p>Kindly acknowledge and release your valuable Order in our favour.</p>
<p>Hope you will give us this opportunity to render our best services to your mills.</p>
<p></p><p></p><p></p><p></p>
<p>Thanking You and assuring of our best service</p>
<p></p><p></p><p></p><p></p>
<p>Yours faithfully,</p>
<p></p>
<p>For <b>SIMTA MACHINERY PRIVATE LIMITED</b></p>
<p></p>
<p><b>Authorised Signatory</b></p>
</body>
EOD;

// print a block of text using Write()
$pdf->writeHTML($txt, true, false, true, false, '');
$pdf->AddPage();
$txt1 = <<<EOD
<style>
body{
                font-size:12px;
                font-familly:Times New Roman;
            }
 table,td{
                //border: 1px solid black;
                border-collapse: collapse;
            }
 .right{
    text-align:right;
 }
 .address{
    //border: 1px solid black;
    border-radius: 25px;
 }
</style>
<body>
<table>
<tr>
<td colspan="0" rowspan="6"><img src="images/logo.png" width="250px" height="250px"></td>
<td colspan="6"><b>SIMTA MACHINERY PRIVATE LIMITED</b></td>
</tr>
<tr>
<td width="300">RAILWAY FEEDER ROAD ,SULUR</td>
<td class="right">Quote No :</td>
<td colspan="2">SIMTA/QUOTE/JAN/3091/R2</td>
</tr>
<tr>
<td>COIMBATORE-641 103</td>
<td class="right">Quote Dt :</td>
<td colspan="2">23-Jan-2018</td>
</tr>
<tr>
<td>GSTIN: 33AAGCS6627J1Z5</td>
<td class="right">Rev No :</td>
<td colspan="2">2</td>
</tr>
<tr>
<td>Ph:04222680705 04222687255</td>
<td class="right">Ref Doc No :</td>
<td colspan="2">MR.GOPAL ARYA</td>
</tr>
<tr>
<td>Email:ohtc@simta.com WebSite:www.simta.com</td>
<td class="right">Ref Doc Dt :</td>
<td colspan="2">20-Jan-2018</td>
</tr>
</table>
<hr>
<p></p>
<table width="100%">
<tr>
<td><b>Billing Address</b></td>
<td><b>Shipping Address</b></td>
</tr>
<tr>
<td>BHASKAR INDUSTRIES (P) LTD.,</td>
<td>BHASKAR INDUSTRIES (P) LTD.,</td>
</tr>
<tr>
<td>WORKS : PLOT NO 15, 16 SECTOR - D,</td>
<td>WORKS : PLOT NO 15, 16 SECTOR - D,</td>
</tr>
<tr>
<td>INDUSTRIAL AREA, MANDIDEEP,</td>
<td>INDUSTRIAL AREA, MANDIDEEP,</td>
</tr>
<tr>
<td>Pincode: 462 046</td>
<td>Pincode: 462 046</td>
</tr>
<tr>
<td>MADHYAPRADESH</td>
<td></td>
</tr>
<tr>
<td>GST Tin :23AAACB5809M1ZP </td>
<td>GST Tin :23AAACB5809M1ZP </td>
</tr>
<tr>
<td>TIN NO: 23213602430</td>
<td>TIN NO: 23213602430</td>
</tr>
<tr>
<td></td>
</tr>
<tr>
<td>Agent : AYUSH AGENCIES</td>
<td>Agent : AYUSH AGENCIES</td>
</tr>
</table>
</body>
EOD;
$pdf->writeHTML($txt1, true, false, true, false, '');
$tb2 = <<<EOD
<style>
            body{
                font-size:12px;
                font-familly:Times New Roman;
            }
            table,td{
                border: 1px solid balck;
                border-collapse: collapse;
                padding: 7px;
            }
            td{
                text-align: center
            }
            .hed{
                text-align:center;
            }
            .date{
                text-align:right;
            }
            .mar{
                margin-top: 100px;
            }
        </style>
        <body>
<table width="100%">
        <tr>
        <td width="40"><b>S.No</b></td>
        <td width="40"><b>PartNo</b></td>
        <td width="340"><b>Item Description</b></td>
        <td width="50"><b>UOM</b></td>
        <td width="70"><b>Quantity</b></td>
        <td width="70"><b>Price Per Unit</b></td>
        <td width="80"><b>Total Value</b></td>
        </tr>
        <tr>
        <td>1</td>
        <td></td>
        <td>STW 50 SUITABLE TO COVER 15 LOOMS IN 1.00 615,570.00 615,570.00
STRAIGHT LINE WITH 92 MTR RAILING AND 1UNIT</td>
        <td>SETS</td>
        <td>1.00</td>
        <td>615,570.00</td>
        <td>615,570.00</td>
        </tr>
        <tr>
        <td>2</td>
        <td></td>
        <td>STW 50 SUITABLE TO COVER 15 LOOMS IN 1.00 615,570.00 615,570.00
STRAIGHT LINE WITH 92 MTR RAILING AND 1UNIT</td>
        <td>SETS</td>
        <td>1.00</td>
        <td>615,570.00</td>
        <td>615,570.00</td>
        </tr>
        <tr>
        <td colspan="4"  rowspan="7" align="center"><b>Rupees: Seven Lakhs Forty Four Thousand Seventy Three Only</b></td>
        <td width="110"><b>Subtotal</b></td>
        <td width="110">Rs 615,570.00</td>
        </tr>
        <tr>
        <td><b>Discount</b></td>
        <td>Rs 0</td>
        </tr>
        <tr>
        <td><b>Packing</b></td>
        <td>Rs 15,000.00</td>
        </tr>
        <tr>
        <td><b>IGST @ 18%</b></td>
        <td>Rs 113,502.60</td>
        </tr>
        <tr>
        <td><b>Grand Total</b></td>
        <td>Rs 744,072.60</td>
        </tr>
        <tr>
        <td><b>R.Off</b></td>
        <td>Rs 0.40</td>
        </tr>
        <tr>
        <td><b>Nett Amount</b></td>
        <td>Rs 744,073.00</td>
        </tr>
</table>
</body>
EOD;
$pdf->writeHTML($tb2, true, false, false, false, '');
$tb3 = <<<EOD
<style>
            body{
                font-size:12px;
                font-familly:Times New Roman;
            }
            table,td{
                //border: 1px solid balck;
                border-collapse: collapse;
            }
        </style>
        <body>
<table width="100%">
<tr>
<td align="right"><b>Terms and Conditions</b></td>
<td></td>
</tr>
<tr>
<td><b>Terms</b></td>
<td><b>Description</b></td>
</tr>
<tr>
<td>PRICE</td>
<td>EX-WORKS</td>
</tr>
<tr>
<td>VALIDITY</td>
<td>45 DAYS</td>
</tr>
<tr>
<td>PAYMENT TERMS</td>
<td>30% WITH ORDER & 70 % AGAINST PROFORMA INVOICE</td>
</tr>
<tr>
<td>DELIVERY TERMS</td>
<td>4 TO 6 WEEKS</td>
</tr>
<tr>
<td>ERECTION CHARGES</td>
<td>1500/DAY</td>
</tr>
<tr>
<td>TO&FRO</td>
<td>Road Permit is Compulsory</td>
</tr>
<tr>
<td>BOARDING&LODGING</td>
<td>TO&FRO, BOARDING&LODGING</td>
</tr>
<tr>
<td>PACKET ALLOWANCE</td>
<td>0.22% EXTRA AT YOUR COST</td>
</tr>
<tr>
<td>EXTRA</td>
<td>0.22% EXTRA AT YOUR COST</td>
</tr>
</table>
<p></p>
<hr>
<span>Bank : SBI ,    Branch : Coimbatore ,   Account : 09876654321677886 ,   IFSC: SBI98765447
</body>
EOD;
$pdf->writeHTML($tb3, true, false, false, false, '');
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('enquiry.pdf', 'I');
	}
}
