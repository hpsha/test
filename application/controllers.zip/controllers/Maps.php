<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Maps extends CI_Controller
{
  function __construct() {
        parent::__construct();
        if (is_logged_in() == true) {
    redirect("welcome");
        }
        $this->load->model('Login_Model');
                        $this->load->library('session');

    }

    public function index()
    {
        $this->load->view('template/header');
        
        $this->load->view('Terms/list_maps');
        
        $this->load->view('template/footer');
    }
}